package org.jbpt.hypergraph.abs;


public interface IEntity extends Cloneable {
	
	public String getLabel();
	
	public Object clone();
	
}
