package org.jbpt.petri;


/**
 * Petri net place interface.
 * 
 * @author Artem Polyvyanyy
 */
public interface IPlace extends INode {
	
	public IPlace clone();
}