package org.jbpt.petri.unfolding;

import org.jbpt.petri.Node;

public abstract class BPNode extends AbstractBPNode<Node> {

}
