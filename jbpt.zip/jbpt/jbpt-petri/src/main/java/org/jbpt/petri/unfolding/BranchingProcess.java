package org.jbpt.petri.unfolding;

import org.jbpt.petri.Flow;
import org.jbpt.petri.Marking;
import org.jbpt.petri.Node;
import org.jbpt.petri.Place;
import org.jbpt.petri.Transition;

public class BranchingProcess extends
		AbstractBranchingProcess<BPNode,Condition,Event,Flow,Node,Place,Transition,Marking> 
{
}
