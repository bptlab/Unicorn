package org.jbpt.algo.tree.mdt;

public enum MDTType {
	TRIVIAL,
	COMPLETE,
	LINEAR,
	PRIMITIVE;
}
