/**
 * 
 */
package org.jbpt.pm.bpmn;

/**
 * Interface for BPMN Start Event.
 * 
 * @author Cindy F�hnrich
 *
 */
public interface IStartEvent extends IBpmnEvent {

}
