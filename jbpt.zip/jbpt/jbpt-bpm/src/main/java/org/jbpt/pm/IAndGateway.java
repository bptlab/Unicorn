/**
 * 
 */
package org.jbpt.pm;

/**
 * Interface for {@link IGateway}s representing the <code>AND</code> semantic.
 * @author Cindy F�hnrich
 *
 */
public interface IAndGateway extends IGateway {

}
