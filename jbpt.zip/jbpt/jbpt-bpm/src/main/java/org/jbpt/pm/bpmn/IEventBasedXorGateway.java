/**
 * 
 */
package org.jbpt.pm.bpmn;

import org.jbpt.pm.IXorGateway;

/**
 * Interface for BPMN EventBasedXorGateway.
 * 
 * @author Cindy F�hnrich
 *
 */
public interface IEventBasedXorGateway extends IXorGateway {

}
