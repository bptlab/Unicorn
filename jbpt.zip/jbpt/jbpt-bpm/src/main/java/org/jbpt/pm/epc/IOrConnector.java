/**
 * 
 */
package org.jbpt.pm.epc;

import org.jbpt.pm.IOrGateway;

/**
 * Interface class for {@link OrConnector}.
 * @author Tobias Hoppe
 *
 */
public interface IOrConnector extends IOrGateway{

}
