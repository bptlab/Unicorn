package org.jbpt.pm.epc;

import org.jbpt.pm.IXorGateway;

/**
 * Interface class for {@link XorConnector}
 * @author Tobias Hoppe
 *
 */
public interface IXorConnector extends IXorGateway{

}
