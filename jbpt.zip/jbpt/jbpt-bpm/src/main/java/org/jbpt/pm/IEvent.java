package org.jbpt.pm;

/**
 * Basic interface for process model events.
 * 
 * @author Tobias Hoppe
 *
 */
public interface IEvent extends IFlowNode {

}
