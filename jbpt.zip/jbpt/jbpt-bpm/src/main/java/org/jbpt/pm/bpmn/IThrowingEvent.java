/**
 * 
 */
package org.jbpt.pm.bpmn;

/**
 * Interface for BPMN Throwing Event.
 * @author Cindy F�hnrich
 *
 */
public interface IThrowingEvent extends IBpmnEvent {

}
