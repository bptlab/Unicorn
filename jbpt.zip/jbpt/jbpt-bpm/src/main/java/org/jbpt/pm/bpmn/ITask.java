/**
 * 
 */
package org.jbpt.pm.bpmn;

/**
 * Interface for BPMN Task class.
 * 
 * @author Cindy F�hnrich
 *
 */
public interface ITask extends IBpmnActivity {

}
