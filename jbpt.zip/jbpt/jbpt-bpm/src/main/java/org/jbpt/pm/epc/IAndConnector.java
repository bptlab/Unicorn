/**
 * 
 */
package org.jbpt.pm.epc;

import org.jbpt.pm.IAndGateway;

/**
 * Interface class for {@link AndConnector}
 * @author Tobias Hoppe
 *
 */
public interface IAndConnector extends IAndGateway {

}
