package org.jbpt.pm.data;

public enum DataConnectionType {
	G, 
	Agg, 
	Ass, 
	UNDEFINED
}