/**
 * 
 */
package org.jbpt.pm;

/**
 * Interface for {@link IGateway}s representing the <code>XOR</code> semantic.
 * @author Cindy Fähnrich
 *
 */
public interface IXorGateway extends IGateway {

}
