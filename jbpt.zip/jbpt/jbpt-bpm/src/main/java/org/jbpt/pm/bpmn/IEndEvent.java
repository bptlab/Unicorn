/**
 * 
 */
package org.jbpt.pm.bpmn;

/**
 * Interface for BPMN End Event.
 * @author Cindy F�hnrich
 *
 */
public interface IEndEvent extends IBpmnEvent {

}
