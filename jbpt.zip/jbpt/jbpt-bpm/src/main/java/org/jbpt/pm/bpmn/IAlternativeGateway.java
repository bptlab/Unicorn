/**
 * 
 */
package org.jbpt.pm.bpmn;

import org.jbpt.pm.IAlternativGateway;

/**
 * Interface class for {@link AlternativeGateway}.
 * @author Tobias Hoppe
 *
 */
public interface IAlternativeGateway extends IAlternativGateway {

}
