/**
 * 
 */
package org.jbpt.pm.bpmn;

/**
 * Interface for BPMN Catching Event.
 * @author Cindy F�hnrich
 *
 */
public interface ICatchingEvent extends IBpmnEvent {

}
