/**
 * 
 */
package org.jbpt.pm;

/**
 * Interface for {@link IGateway}s representing the <code>OR</code> semantic.
 * @author Cindy F�hnrich
 *
 */
public interface IOrGateway extends IGateway {

}
