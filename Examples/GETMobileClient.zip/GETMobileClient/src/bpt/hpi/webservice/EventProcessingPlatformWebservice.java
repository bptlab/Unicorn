

/**
 * EventProcessingPlatformWebservice.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.2  Built on : Apr 17, 2012 (05:33:49 IST)
 */

    package bpt.hpi.webservice;

    /*
     *  EventProcessingPlatformWebservice java interface
     */

    public interface EventProcessingPlatformWebservice {
          

        /**
          * Auto generated method signature
          * 
                    * @param importSemanticEventMapping0
                
         */

         
                     public bpt.hpi.webservice.ImportSemanticEventMappingResponse importSemanticEventMapping(

                        bpt.hpi.webservice.ImportSemanticEventMapping importSemanticEventMapping0)
                        throws java.rmi.RemoteException
             ;

        
         /**
            * Auto generated method signature for Asynchronous Invocations
            * 
                * @param importSemanticEventMapping0
            
          */
        public void startimportSemanticEventMapping(

            bpt.hpi.webservice.ImportSemanticEventMapping importSemanticEventMapping0,

            final bpt.hpi.webservice.EventProcessingPlatformWebserviceCallbackHandler callback)

            throws java.rmi.RemoteException;

     

        /**
          * Auto generated method signature
          * 
                    * @param unregisterQueriesFromQueue2
                
         */

         
                     public bpt.hpi.webservice.UnregisterQueriesFromQueueResponse unregisterQueriesFromQueue(

                        bpt.hpi.webservice.UnregisterQueriesFromQueue unregisterQueriesFromQueue2)
                        throws java.rmi.RemoteException
             ;

        
         /**
            * Auto generated method signature for Asynchronous Invocations
            * 
                * @param unregisterQueriesFromQueue2
            
          */
        public void startunregisterQueriesFromQueue(

            bpt.hpi.webservice.UnregisterQueriesFromQueue unregisterQueriesFromQueue2,

            final bpt.hpi.webservice.EventProcessingPlatformWebserviceCallbackHandler callback)

            throws java.rmi.RemoteException;

     

        /**
          * Auto generated method signature
          * 
                    * @param unregisterEventAggregationRule4
                
         */

         
                     public bpt.hpi.webservice.UnregisterEventAggregationRuleResponse unregisterEventAggregationRule(

                        bpt.hpi.webservice.UnregisterEventAggregationRule unregisterEventAggregationRule4)
                        throws java.rmi.RemoteException
             ;

        
         /**
            * Auto generated method signature for Asynchronous Invocations
            * 
                * @param unregisterEventAggregationRule4
            
          */
        public void startunregisterEventAggregationRule(

            bpt.hpi.webservice.UnregisterEventAggregationRule unregisterEventAggregationRule4,

            final bpt.hpi.webservice.EventProcessingPlatformWebserviceCallbackHandler callback)

            throws java.rmi.RemoteException;

     

        /**
          * Auto generated method signature
          * 
                    * @param registerEventAggregationRule6
                
         */

         
                     public bpt.hpi.webservice.RegisterEventAggregationRuleResponse registerEventAggregationRule(

                        bpt.hpi.webservice.RegisterEventAggregationRule registerEventAggregationRule6)
                        throws java.rmi.RemoteException
             ;

        
         /**
            * Auto generated method signature for Asynchronous Invocations
            * 
                * @param registerEventAggregationRule6
            
          */
        public void startregisterEventAggregationRule(

            bpt.hpi.webservice.RegisterEventAggregationRule registerEventAggregationRule6,

            final bpt.hpi.webservice.EventProcessingPlatformWebserviceCallbackHandler callback)

            throws java.rmi.RemoteException;

     

        /**
          * Auto generated method signature
          * 
                    * @param importRoute8
                
         */

         
                     public bpt.hpi.webservice.ImportRouteResponse importRoute(

                        bpt.hpi.webservice.ImportRoute importRoute8)
                        throws java.rmi.RemoteException
             ;

        
         /**
            * Auto generated method signature for Asynchronous Invocations
            * 
                * @param importRoute8
            
          */
        public void startimportRoute(

            bpt.hpi.webservice.ImportRoute importRoute8,

            final bpt.hpi.webservice.EventProcessingPlatformWebserviceCallbackHandler callback)

            throws java.rmi.RemoteException;

     

        /**
          * Auto generated method signature
          * 
                    * @param registerQueryForQueue10
                
         */

         
                     public bpt.hpi.webservice.RegisterQueryForQueueResponse registerQueryForQueue(

                        bpt.hpi.webservice.RegisterQueryForQueue registerQueryForQueue10)
                        throws java.rmi.RemoteException
             ;

        
         /**
            * Auto generated method signature for Asynchronous Invocations
            * 
                * @param registerQueryForQueue10
            
          */
        public void startregisterQueryForQueue(

            bpt.hpi.webservice.RegisterQueryForQueue registerQueryForQueue10,

            final bpt.hpi.webservice.EventProcessingPlatformWebserviceCallbackHandler callback)

            throws java.rmi.RemoteException;

     

        /**
          * Auto generated method signature
          * 
                    * @param unregisterEventType12
                
         */

         
                     public bpt.hpi.webservice.UnregisterEventTypeResponse unregisterEventType(

                        bpt.hpi.webservice.UnregisterEventType unregisterEventType12)
                        throws java.rmi.RemoteException
             ;

        
         /**
            * Auto generated method signature for Asynchronous Invocations
            * 
                * @param unregisterEventType12
            
          */
        public void startunregisterEventType(

            bpt.hpi.webservice.UnregisterEventType unregisterEventType12,

            final bpt.hpi.webservice.EventProcessingPlatformWebserviceCallbackHandler callback)

            throws java.rmi.RemoteException;

     

        /**
          * Auto generated method signature
          * 
                    * @param unregisterQueryFromQueue14
                
         */

         
                     public bpt.hpi.webservice.UnregisterQueryFromQueueResponse unregisterQueryFromQueue(

                        bpt.hpi.webservice.UnregisterQueryFromQueue unregisterQueryFromQueue14)
                        throws java.rmi.RemoteException
             ;

        
         /**
            * Auto generated method signature for Asynchronous Invocations
            * 
                * @param unregisterQueryFromQueue14
            
          */
        public void startunregisterQueryFromQueue(

            bpt.hpi.webservice.UnregisterQueryFromQueue unregisterQueryFromQueue14,

            final bpt.hpi.webservice.EventProcessingPlatformWebserviceCallbackHandler callback)

            throws java.rmi.RemoteException;

     

        /**
          * Auto generated method signature
          * 
                    * @param importEvents16
                
             * @throws bpt.hpi.webservice.EventProcessingPlatformWebserviceXMLParsingExceptionException : 
         */

         
                     public bpt.hpi.webservice.ImportEventsResponse importEvents(

                        bpt.hpi.webservice.ImportEvents importEvents16)
                        throws java.rmi.RemoteException
             
          ,bpt.hpi.webservice.EventProcessingPlatformWebserviceXMLParsingExceptionException;

        
         /**
            * Auto generated method signature for Asynchronous Invocations
            * 
                * @param importEvents16
            
          */
        public void startimportEvents(

            bpt.hpi.webservice.ImportEvents importEvents16,

            final bpt.hpi.webservice.EventProcessingPlatformWebserviceCallbackHandler callback)

            throws java.rmi.RemoteException;

     

        /**
          * Auto generated method signature
          * 
                    * @param registerEventType18
                
         */

         
                     public bpt.hpi.webservice.RegisterEventTypeResponse registerEventType(

                        bpt.hpi.webservice.RegisterEventType registerEventType18)
                        throws java.rmi.RemoteException
             ;

        
         /**
            * Auto generated method signature for Asynchronous Invocations
            * 
                * @param registerEventType18
            
          */
        public void startregisterEventType(

            bpt.hpi.webservice.RegisterEventType registerEventType18,

            final bpt.hpi.webservice.EventProcessingPlatformWebserviceCallbackHandler callback)

            throws java.rmi.RemoteException;

     

        
       //
       }
    