
/**
 * EventProcessingPlatformWebserviceXMLParsingExceptionException.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.2  Built on : Apr 17, 2012 (05:33:49 IST)
 */

package bpt.hpi.webservice;

public class EventProcessingPlatformWebserviceXMLParsingExceptionException extends java.lang.Exception{

    private static final long serialVersionUID = 1399124558497L;
    
    private bpt.hpi.webservice.EventProcessingPlatformWebserviceXMLParsingException faultMessage;

    
        public EventProcessingPlatformWebserviceXMLParsingExceptionException() {
            super("EventProcessingPlatformWebserviceXMLParsingExceptionException");
        }

        public EventProcessingPlatformWebserviceXMLParsingExceptionException(java.lang.String s) {
           super(s);
        }

        public EventProcessingPlatformWebserviceXMLParsingExceptionException(java.lang.String s, java.lang.Throwable ex) {
          super(s, ex);
        }

        public EventProcessingPlatformWebserviceXMLParsingExceptionException(java.lang.Throwable cause) {
            super(cause);
        }
    

    public void setFaultMessage(bpt.hpi.webservice.EventProcessingPlatformWebserviceXMLParsingException msg){
       faultMessage = msg;
    }
    
    public bpt.hpi.webservice.EventProcessingPlatformWebserviceXMLParsingException getFaultMessage(){
       return faultMessage;
    }
}
    