package bpt.hpi.messaging;

import java.rmi.RemoteException;

import bpt.hpi.webservice.EventProcessingPlatformWebserviceStub;
import bpt.hpi.webservice.RegisterEventType;

public class ProducerJMSClientAdvertise {
	
	public static void main(String[] args) throws RemoteException {
	EventProcessingPlatformWebserviceStub stub = new EventProcessingPlatformWebserviceStub();

	//upload event type "VehicleLocationEventType"
	RegisterEventType registerVehicleLocationEventType =  new RegisterEventType();
	String vehicleLocationEventTypeString = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
		"<xs:schema xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns=\"VehicleLocationEventType.xsd\" targetNamespace=\"VehicleLocationEventType.xsd\" elementFormDefault=\"qualified\">"
		    + "<xs:element name=\"VehicleLocationEvent\"> "
			    + "<xs:complexType>"
			    	+ "<xs:sequence>"
			    		+ "<xs:element name=\"mobOperID\" type=\"xs:integer\"/>"
			    		+ "<xs:element name=\"latitude\" type=\"xs:string\"/>"
			    		+ "<xs:element name=\"longitude\" type=\"xs:string\"/>"
			    		+ "<xs:element name=\"altitude\" type=\"xs:string\"/>"
					+ "</xs:sequence>"
				+ "</xs:complexType>"
				+ "</xs:element>"
		+ "</xs:schema>";
	registerVehicleLocationEventType.setXsd(vehicleLocationEventTypeString);
	registerVehicleLocationEventType.setSchemaName("VehicleLocationEventType");
	stub.registerEventType(registerVehicleLocationEventType);
	
	}

}
