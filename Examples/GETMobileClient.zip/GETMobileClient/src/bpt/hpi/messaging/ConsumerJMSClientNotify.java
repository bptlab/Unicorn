package bpt.hpi.messaging;

import java.rmi.RemoteException;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;

public class ConsumerJMSClientNotify {

	private static String brokerHost;
	private static String brokerPort;
	private static String queue;

	public static void main(String[] args) throws RemoteException {

		brokerHost = "bpt.hpi.uni-potsdam.de";
		brokerPort = "61616";

		// Enter your queue here
		queue = "";

		initializeBrokerConnection(brokerHost, brokerPort, queue);

	}

	private static void initializeBrokerConnection(String brokerHost2,
			String brokerPort2, String queue2) {

		if (queue.equalsIgnoreCase("")) {
			System.out
					.println("Please enter your queue ID in the class to run it!");
		} else {
			try {

				// Create a ConnectionFactory
				ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(
						String.format("tcp://%s:%s", brokerHost2, brokerPort2));

				// Create a Connection
				Connection connection = connectionFactory.createConnection();
				connection.start();
				System.out.println("Connection established");

				// Create a Session
				Session session = connection.createSession(false,
						Session.AUTO_ACKNOWLEDGE);

				// Create the destination (Topic or Queue)
				Destination destination = session.createQueue(queue2);

				// Create a MessageConsumer from the Session to the Topic or
				// Queue
				MessageConsumer consumer = session.createConsumer(destination);

				// Wait for a message
				while (true) {
					System.out.println("Waiting for messages");
					Message message = consumer.receive(0);

					if (message instanceof TextMessage) {
						TextMessage textMessage = (TextMessage) message;
						String text = textMessage.getText();
						System.out.println("Received: " + text);
					} else {
						System.out.println("Received: " + message);
					}

				}
			} catch (Exception e) {
				System.out.println("Caught: " + e);
				e.printStackTrace();
			}

		}
	}

}
