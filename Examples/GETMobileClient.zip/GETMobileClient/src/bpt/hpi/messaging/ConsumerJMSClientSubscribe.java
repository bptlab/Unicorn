package bpt.hpi.messaging;

import java.rmi.RemoteException;

import bpt.hpi.webservice.EventProcessingPlatformWebserviceStub;
import bpt.hpi.webservice.RegisterQueryForQueue;
import bpt.hpi.webservice.RegisterQueryForQueueResponse;

public class ConsumerJMSClientSubscribe {

	// Enter your email here
	private static String email = "";

	// Enter the query here
	private static String query = "Select v.mobOperID as mobOperID, v.altitude as altitude, "
			+ "v.latitude as latitude, v.longitude as longitude "
			+ "FROM VehicleLocationEventType as v";

	private static String title = "VehicleUpdate";

	public static void main(String[] args) throws RemoteException {
		
		if (email.equalsIgnoreCase("")) {
			System.out
					.println("Please enter your email in the class to run it!");
		} else {
			EventProcessingPlatformWebserviceStub stub = new EventProcessingPlatformWebserviceStub();

			// register query
			RegisterQueryForQueue queryqueue = new RegisterQueryForQueue();
			queryqueue.setTitle(title);
			queryqueue.setQueryString(query);
			queryqueue.setEMail(email);
			RegisterQueryForQueueResponse response = stub
					.registerQueryForQueue(queryqueue);
			System.out.println("Get notified by the following queue: "
					+ response.get_return());
		}
	}

}
