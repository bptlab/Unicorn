package bpt.hpi.messaging;

import java.rmi.RemoteException;

import bpt.hpi.webservice.EventProcessingPlatformWebserviceStub;
import bpt.hpi.webservice.RegisterEventType;
import bpt.hpi.webservice.UnregisterEventType;
import bpt.hpi.webservice.UnregisterEventTypeResponse;

public class ProducerJMSClientUnadvertise {

	public static void main(String[] args) throws RemoteException {
		EventProcessingPlatformWebserviceStub stub = new EventProcessingPlatformWebserviceStub();

		// remove event type "VehicleLocationEventType"
		UnregisterEventType typeSmoke = new UnregisterEventType();
		typeSmoke.setSchemaName("VehicleLocationEventType");
		stub.unregisterEventType(typeSmoke);

	}

}
