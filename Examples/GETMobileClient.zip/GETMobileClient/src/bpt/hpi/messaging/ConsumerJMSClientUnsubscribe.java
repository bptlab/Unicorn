package bpt.hpi.messaging;

import java.rmi.RemoteException;

import bpt.hpi.webservice.EventProcessingPlatformWebserviceStub;
import bpt.hpi.webservice.UnregisterQueryFromQueue;

public class ConsumerJMSClientUnsubscribe {

	// Enter your queue here
	private static String queue = "";

	public static void main(String[] args) throws RemoteException {
		
		if (queue.equalsIgnoreCase("")) {
			System.out
					.println("Please enter your queue ID in the class to run it!");
		} else {
			
		EventProcessingPlatformWebserviceStub stub = new EventProcessingPlatformWebserviceStub();
		
		// unregister query
		UnregisterQueryFromQueue queryqueue = new UnregisterQueryFromQueue();
		queryqueue.setUuid(queue);
		stub.unregisterQueryFromQueue(queryqueue);

		}

	}

}
