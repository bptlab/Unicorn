package bpt.hpi.messaging;

import java.rmi.RemoteException;

import bpt.hpi.webservice.EventProcessingPlatformWebserviceStub;
import bpt.hpi.webservice.EventProcessingPlatformWebserviceXMLParsingExceptionException;
import bpt.hpi.webservice.ImportEvents;

public class ProducerJMSClientPublish {
	
	public static void main(String[] args) throws RemoteException, EventProcessingPlatformWebserviceXMLParsingExceptionException {
	EventProcessingPlatformWebserviceStub stub = new EventProcessingPlatformWebserviceStub();

	//upload event
	ImportEvents vehicleEvent = new ImportEvents();
	String vehicleLocationEventString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
			+ "<VehicleLocationEvent xmlns=\"\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"VehicleLocationEventType.xsd\">"
			+ "<mobOperID>7276</mobOperID>"
			+ "<altitude>72</altitude>"
			+ "<latitude>49.0219268798828</latitude>"
			+ "<longitude>8.46284008026123</longitude>"
			+ "</VehicleLocationEvent>";
	vehicleEvent.setXml(vehicleLocationEventString);
	stub.importEvents(vehicleEvent);
	}

}
