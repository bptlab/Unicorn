package bpt.hpi.messaging;

import java.rmi.RemoteException;

import bpt.hpi.webservice.EventProcessingPlatformWebserviceStub;
import bpt.hpi.webservice.UnregisterQueriesFromQueue;

public class ConsumerJMSClientUnsubscribeAllEmail {
	
	// Enter your email here
	private static String email = "";

	public static void main(String[] args) throws RemoteException {


		if (email.equalsIgnoreCase("")) {
			System.out
					.println("Please enter your email in the class to run it!");
		} else {
		EventProcessingPlatformWebserviceStub stub = new EventProcessingPlatformWebserviceStub();

		// unregister query
		UnregisterQueriesFromQueue queryqueue = new UnregisterQueriesFromQueue();
		queryqueue.setEmail(email);
		stub.unregisterQueriesFromQueue(queryqueue);
		}

	}

}
